import streamlit as st
import requests
from datetime import datetime

BACKEND_URL = "http://backend:8000"

# Session State Setup
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'user_phone' not in st.session_state:
    st.session_state.user_phone = ""

# Helper Functions
def validate_phone(phone):
    return phone.startswith("+92") and len(phone) == 13

# UI Components
st.title("EasyPaisa/JazzCash Portal")

# Registration Form
with st.expander("New User Registration"):
    reg_phone = st.text_input("Phone (+92XXXXXXXXXX)", key="reg_phone")
    reg_password = st.text_input("Password", type="password", key="reg_pass")
    reg_name = st.text_input("Full Name")
    reg_cnic = st.text_input("CNIC (XXXXX-XXXXXXX-X)")
    
    if st.button("Register"):
        if not validate_phone(reg_phone):
            st.error("Invalid phone format!")
        else:
            try:
                response = requests.post(
                    f"{BACKEND_URL}/register",
                    json={
                        "user_id": f"user_{datetime.now().timestamp()}",
                        "phone": reg_phone,
                        "password": reg_password,
                        "full_name": reg_name,
                        "cnic": reg_cnic
                    }
                )
                if response.status_code == 200:
                    st.success("Registration successful! Please login")
                else:
                    st.error(response.json().get("detail", "Registration failed"))
            except Exception as e:
                st.error(f"Connection error: {str(e)}")

# Login Form
with st.expander("Login"):
    login_phone = st.text_input("Phone", key="login_phone")
    login_pass = st.text_input("Password", type="password", key="login_pass")
    
    if st.button("Login"):
        try:
            response = requests.post(
                f"{BACKEND_URL}/login",
                json={"phone": login_phone, "password": login_pass}
            )
            if response.status_code == 200:
                st.session_state.logged_in = True
                st.session_state.user_phone = login_phone
                st.success("Login successful!")
            else:
                st.error("Invalid phone or password")
        except Exception as e:
            st.error(f"Connection error: {str(e)}")

# Logged-in Features
if st.session_state.logged_in:
    st.header(f"Welcome, {st.session_state.user_phone}")
    
    # Transaction Form
    with st.form("transaction_form"):
        st.subheader("New Transaction")
        receiver = st.text_input("Receiver Phone (+92XXXXXXXXXX)")
        amount = st.number_input("Amount (PKR)", min_value=10, value=100)
        
        if st.form_submit_button("Send Money"):
            if not validate_phone(receiver):
                st.error("Invalid receiver phone format!")
            else:
                try:
                    response = requests.post(
                        f"{BACKEND_URL}/transactions",
                        json={
                            "txn_id": f"txn_{datetime.now().timestamp()}",
                            "sender_phone": st.session_state.user_phone,
                            "receiver_phone": receiver,
                            "amount": amount
                        }
                    )
                    if response.status_code == 200:
                        st.success("Transaction successful!")
                    else:
                        st.error(response.json().get("detail", "Transaction failed"))
                except Exception as e:
                    st.error(f"Connection error: {str(e)}")
    
    # Transaction History
    st.subheader("Your Transactions")
    if st.button("Refresh History"):
        try:
            transactions = requests.get(
                f"{BACKEND_URL}/transactions/{st.session_state.user_phone}"
            ).json()
            if transactions:
                st.table(transactions)
            else:
                st.info("No transactions found")
        except Exception as e:
            st.error(f"Error loading transactions: {str(e)}")
    
    # Logout
    if st.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.user_phone = ""
        st.experimental_rerun()