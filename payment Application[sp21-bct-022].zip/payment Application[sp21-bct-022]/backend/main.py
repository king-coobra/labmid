from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, validator
from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorClient
import os
from passlib.context import CryptContext
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()

# MongoDB Configuration
MONGO_URI = os.getenv("MONGO_URI", "mongodb://admin:password@mongodb:27017/payment_app?authSource=admin&retryWrites=true&w=majority")
client = AsyncIOMotorClient(MONGO_URI)
db = client.get_database()

# Security
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Models
class User(BaseModel):
    user_id: str
    phone: str
    password: str
    full_name: str = ""
    cnic: str = ""
    created_at: datetime = datetime.now()

    @validator('phone')
    def validate_phone(cls, v):
        if not v.startswith("+92") or len(v) != 13:
            raise ValueError("Invalid phone format: +92XXXXXXXXXX")
        return v

class Transaction(BaseModel):
    txn_id: str
    sender_phone: str
    receiver_phone: str
    amount: float
    timestamp: datetime = datetime.now()

# Database Initialization
@app.on_event("startup")
async def startup_db():
    try:
        # Verify connection works
        await client.admin.command('ping')
        logger.info("✅ Successfully connected to MongoDB")
        
        # Create indexes
        await db.users.create_index("phone", unique=True)
        await db.transactions.create_index("txn_id", unique=True)
        logger.info("✅ Created database indexes")
    except Exception as e:
        logger.error(f"❌ MongoDB initialization failed: {e}")
        raise

# User Endpoints
@app.post("/register")
async def register_user(user: User):
    try:
        user_dict = user.dict()
        user_dict["password"] = pwd_context.hash(user.password)
        user_dict["created_at"] = datetime.now()
        
        result = await db.users.insert_one(user_dict)
        if not result.acknowledged:
            raise Exception("Insert operation not acknowledged by MongoDB")
            
        logger.info(f"✅ Registered user: {user.phone} with ID: {result.inserted_id}")
        return {"message": "User registered successfully"}
    except Exception as e:
        logger.error(f"❌ Registration failed for {user.phone}: {str(e)}")
        if "duplicate key error" in str(e).lower():
            raise HTTPException(status_code=400, detail="Phone already exists")
        raise HTTPException(status_code=500, detail="Registration failed")

@app.post("/login")
@app.post("/login")
async def login_user(user: User):  # Change from separate params to User model
    db_user = await db.users.find_one({"phone": user.phone})
    if not db_user or not pwd_context.verify(user.password, db_user["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return {
        "message": "Login successful",
        "user_id": db_user["user_id"],
        "phone": db_user["phone"]
    }
   
# Transaction Endpoints
@app.post("/transactions")
async def create_transaction(transaction: Transaction):
    try:
        transaction_dict = transaction.dict()
        result = await db.transactions.insert_one(transaction_dict)
        
        if not result.acknowledged:
            raise Exception("Transaction not acknowledged by MongoDB")
            
        logger.info(f"✅ Created transaction: {transaction.txn_id}")
        return {"message": "Transaction created", "txn_id": transaction.txn_id}
    except Exception as e:
        logger.error(f"❌ Transaction failed: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/transactions/{phone}")
async def get_transactions(phone: str):
    try:
        transactions = await db.transactions.find({
            "$or": [
                {"sender_phone": phone.strip()},
                {"receiver_phone": phone.strip()}
            ]
        }).to_list(100)
        
        logger.info(f"✅ Retrieved {len(transactions)} transactions for {phone}")
        return transactions
    except Exception as e:
        logger.error(f"❌ Failed to get transactions: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to get transactions")